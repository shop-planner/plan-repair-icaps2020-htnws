"""extractTimes.py

Started On: 05 November 2018
Last Updated: 27 September 2019

Extracts the time durations for plan repair studies and puts them into a .csv file
NOTE: This is the LPG version, which is different from the SHOP version
"""

#Used for arrays and some math functions
import numpy
#Used to get system paths
import subprocess
#Used if called via the command line (gets those arguments)
import argparse

#The default domain is used if one is not provided
#default_domain = "openstacks"
#default_domain = "rovers"
default_domain = "satellite"

#The default path is used if one is not provided
default_path = subprocess.check_output(["pwd"])[:-1] + "/"
#default_path = "/Users/freedman/myFiles/sift/projects/laplata/trunk/code/shop2LPG/results/distanceComputations/lpg_plans/" + default_domain + "/results/"
#default_path = "/home/freedman/sift/lpgStuff/laplata/trunk/code/shop2LPG/results/distanceComputations/lpg_plans/openstacks/results/"
#default_path = "/home/freedman/sift/lpgStuff/laplata/trunk/code/shop2LPG/results/distanceComputations/lpg_plans/rovers/results/"
#default_path = "/Users/freedman/myFiles/sift/projects/laplata/trunk/code/shop2LPG/results/distanceComputations/lpg_plans/rovers/results/"

def consolidateTimes(from_problem, to_problem, num_trials, tested = "repair", filepath = default_path, output_file = "times.csv"):
    """Put all the times into a well-organized spreadsheet in the .csv format

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .csv file, prepended by tested
             [DEFAULT value = "times.csv"]
    Returns:
    (void)
    """
    #First create the file to which we will write the data
    outfile = open(tested + "_" + output_file, 'w')
    #Write the header row for what each data column represents
    outfile.write("Problem Number")
    for trial in range(num_trials): outfile.write(",Total Time Trial" + str(trial))
    for trial in range(num_trials): outfile.write(",Search Time Trial" + str(trial))
    outfile.write('\n')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order
    data_to_print = numpy.zeros(num_trials * 2)
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            input_file = filepath + "lpg_" + tested + "_output_p" + (("0" + str(problem)) if problem < 10 else str(problem)) + "_trial" + str(trial) + ".txt"
            infile = open(input_file, 'r')
            #Store all the data, delimited by whitespace
            data_dump = [line.split() for line in infile.readlines()]
            #No longer need the input file
            infile.close()

            #print data_dump
            #print problem, trial, '\n'
            
            #Find the total and search time entries to record in the array
            #NOTE: The file might be empty if it hit a segmentation fault!
            #NOTE2: If segmentation fault comes from memory exhaustion, then the
            #       output file WILL contain data, but no time information
            if len(data_dump) == 0 or len([i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"]) == 0:
                data_to_print[trial] = -1.0
                data_to_print[trial + num_trials] = -1.0
            else:
                #WARNING: This is a bit of a hack, **assuming** that the fields are
                #  printed left-most with exact strings and tabbing format
                #NOTE: Since some lines are empty, check the length first!
                data_to_print[trial] = [i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"][0][2]
                data_to_print[trial + num_trials] = [i for i in data_dump if len(i) >= 3 and i[0]=="Search" and i[1]=="time:"][0][2]

        #Print the line over all the trials for the problem before moving onto the next one
        outfile.write(str(problem))
        for i in data_to_print: outfile.write("," + str(i))
        outfile.write('\n')

    #Done with the output file
    outfile.flush()
    outfile.close()

def plotTimes(from_problem, to_problem, num_trials, tested = "repair", filepath = default_path, output_file = "times.dat"):
    """Puts all the times and their average into a (GNUplot) plottable .dat file

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .dat file, prepended by tested
             [DEFAULT value = "times.dat"]
    Returns:
    (void)
    """
    #First create the file to which we will write the data
    outfile = open(tested + "_" + output_file, 'w')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order (it will be modified for .dat files)
    data_to_print = numpy.zeros((to_problem - from_problem + 1, num_trials * 2))
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            input_file = filepath + "lpg_" + tested + "_output_p" + (("0" + str(problem)) if problem < 10 else str(problem)) + "_trial" + str(trial) + ".txt"
            infile = open(input_file, 'r')
            #Store all the data, delimited by whitespace
            data_dump = [line.split() for line in infile.readlines()]
            #No longer need the input file
            infile.close()

            #print data_dump
            #print problem, trial, '\n'
            
            #Find the total and search time entries to record in the array
            #NOTE: The file might be empty if it hit a segmentation fault!
            #NOTE2: If segmentation fault comes from memory exhaustion, then the
            #       output file WILL contain data, but no time information
            if len(data_dump) == 0 or len([i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"]) == 0:
                data_to_print[problem - from_problem][trial] = -1.0
                data_to_print[problem - from_problem][trial + num_trials] = -1.0
            else:
                #WARNING: This is a bit of a hack, **assuming** that the fields are
                #  printed left-most with exact strings and tabbing format
                #NOTE: Since some lines are empty, check the length first!
                data_to_print[problem - from_problem][trial] = [i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"][0][2]
                data_to_print[problem - from_problem][trial + num_trials] = [i for i in data_dump if len(i) >= 3 and i[0]=="Search" and i[1]=="time:"][0][2]

    #Write the header row for what each data column represents in the scatter plot
    outfile.write("#Scatter Plot (index 0)\n# Problem Number (X) | Total Time (Y)\n")
    #Print each point in the scatter plot, a blank space in between will not draw the line
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for totalTimeValue in problemValues[:num_trials]:
            outfile.write(str(problemId) + ' ' + str(totalTimeValue) + '\n\n')

    #Need two extra line breaks for the new set of points to plot
    outfile.write("\n\n#Scatter Plot (index 1)\n# Problem Number (X) | Search Time (Y)\n")
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for searchTimeValue in problemValues[num_trials:]:
            outfile.write(str(problemId) + ' ' + str(searchTimeValue) + '\n\n')

    #Need two extra line breaks for the new set of points to plot
    outfile.write("\n#Line Plot (index 2)\n# Problem Number (X) | Average Total Time (Y)\n")
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        outfile.write(str(problemId) + ' ' + str(numpy.average(numpy.array([i for i in problemValues[:num_trials] if i >= 0.0]))) + '\n')

    #Need two extra line breaks for the new set of points to plot
    outfile.write("\n\n#Line Plot (index 3)\n# Problem Number (X) | Average Search Time (Y)\n")
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        outfile.write(str(problemId) + ' ' + str(numpy.average(numpy.array([i for i in problemValues[num_trials:] if i >= 0.0]))) + '\n')

    #Done with the output file
    outfile.flush()
    outfile.close()

def plotAllTimes(from_problem, to_problem, num_trials, filepath = default_path, output_file = "alltimes.dat"):
    """Puts all the times and their average into a (GNUplot) plottable .dat file
       that will render a scatter and line plot

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .dat file, prepended by tested
             [DEFAULT value = "timesbox.dat"]
    Returns:
    (void)
    """
    #Columns of plan_times.txt
    REPAIR_TIME_COL = 0
    REPLAN_TIME_COL = 1

    #Lists the possible tests, which will all be compiled into one file now
    total_tests = ["repair", "replan"]
    
    #First create the file to which we will write the data
    outfile = open(output_file, 'w')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order (it will be modified for .dat files)
    data_to_print = numpy.zeros((to_problem - from_problem + 1, num_trials * 2, len(total_tests)))
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            for tested in range(len(total_tests)):
                input_file = filepath + "lpg_" + total_tests[tested] + "_output_p" + (("0" + str(problem)) if problem < 10 else str(problem)) + "_trial" + str(trial) + ".txt"
                infile = open(input_file, 'r')
                #Store all the data, delimited by whitespace
                data_dump = [line.split() for line in infile.readlines()]
                #No longer need the input file
                infile.close()

                #print data_dump
                #print problem, trial, '\n'
            
                #Find the total and search time entries to record in the array
                #NOTE: The file might be empty if it hit a segmentation fault!
                #NOTE2: If segmentation fault comes from memory exhaustion, then the
                #       output file WILL contain data, but no time information
                if len(data_dump) == 0 or len([i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"]) == 0:
                    data_to_print[problem - from_problem][trial][tested] = -1.0
                    data_to_print[problem - from_problem][trial + num_trials][tested] = -1.0
                else:
                    #WARNING: This is a bit of a hack, **assuming** that the fields are
                    #  printed left-most with exact strings and tabbing format
                    #NOTE: Since some lines are empty, check the length first!
                    data_to_print[problem - from_problem][trial][tested] = [i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"][0][2]
                    data_to_print[problem - from_problem][trial + num_trials][tested] = [i for i in data_dump if len(i) >= 3 and i[0]=="Search" and i[1]=="time:"][0][2]

    #Write the header row for what each data column represents in the scatter plot
    outfile.write("#Scatter Plot (index 0)\n# Problem Number (X) | Total Plan Repair Time (Y)\n")
    #Print each point in the scatter plot
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for (totalTimeValue, searchTimeValue) in zip(problemValues[:num_trials], problemValues[num_trials:]):
            outfile.write(str(problemId) + ' ' + str(totalTimeValue[REPAIR_TIME_COL]) + '\n\n')

    #This will separate the indeces
    outfile.write("\n\n")
    
    outfile.write("#Scatter Plot (index 1)\n# Problem Number (X) | Total Replan Time (Y)\n")
    #Print each point in the scatter plot
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for (totalTimeValue, searchTimeValue) in zip(problemValues[:num_trials], problemValues[num_trials:]):
            outfile.write(str(problemId) + ' ' + str(totalTimeValue[REPLAN_TIME_COL]) + '\n\n')

    #This will separate the indeces
    outfile.write("\n\n")
    
    outfile.write("#Line Plot (index 2)\n# Problem Number (X) | Average Total Repair Time (Y)\n")
    #Print each point in the scatter plot
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        #Compute the averages over all the trials per problem
        avgTotalTimeValue = numpy.average(problemValues[:num_trials][REPAIR_TIME_COL])
        avgSearchTimeValue = numpy.average(problemValues[num_trials:][REPAIR_TIME_COL])
        outfile.write(str(problemId) + ' ' + str(avgTotalTimeValue) + '\n')

    #This will separate the indeces
    outfile.write("\n\n")
    
    outfile.write("#Line Plot (index 3)\n# Problem Number (X) | Average Total Replan Time (Y)\n")
    #Print each point in the scatter plot
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        #Compute the averages over all the trials per problem
        avgTotalTimeValue = numpy.average(problemValues[:num_trials][REPLAN_TIME_COL])
        avgSearchTimeValue = numpy.average(problemValues[num_trials:][REPLAN_TIME_COL])
        outfile.write(str(problemId) + ' ' + str(avgTotalTimeValue) + '\n')
        
    #Done with the output file
    outfile.flush()
    outfile.close()
    
def plotGNU(from_problem, to_problem, tested = "repair", domain = default_domain, data_file = None, filepath = default_path, output_file = ".gnu"):
    """Creates a .gnu file for generating a scatter plot of the above data

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) domain = the domain (either "openstacks" or "rovers" or "satellite" for now)
    (string) data_file = the name of the file with the data; uses a default if None
             [DEFAULT value = None]
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .gnu file, prepended by tested
             [DEFAULT value = ".gnu"]
    Returns:
    (void)
    """
    #First create the file to which we will write the data
    outfile = open("plotTimes_" + tested + output_file, 'w')

    #Begin with the shebang header
    outfile.write("#!/usr/bin/gnuplot\n\n")

    #Begin with the shebang header
    ###NOTE: There are updates to the shebang header format based on Robert's 
    ###      efforts to get his machine to render PDFs properly - these may not
    ###      appear in other GNUplot file generating functions above!
    ###NOTE: We remove the newline at the end of the stdout for the which command
    gnuplot_path = subprocess.check_output(["which", "gnuplot"])[:-1]
    outfile.write("#!" + gnuplot_path + " -c\n\nname = \'lpg_" + domain + "_" + tested + "_time_plots\'\n\ncall \"../../../output-prefix.gnu\" ARG1\n\n")

    #Next is the general header information such as documentation, clearing
    #  anything cached, setup parameters, etc.
    outfile.write("#Plotting times taken to run LPG's plan " + tested + "\n\n")
    """
    ###NOTE: The reset and file naming below are removed in exchange for Robert's
    ###      changes above (the PDF printing does not need the PNG printing stuff)
    outfile.write("reset\n\n")
    outfile.write("#PDF file failed to show axes; so changed to PNG...\n")
    outfile.write("set term pngcairo size 700,400\n")
    outfile.write("set output \'lpg_" + domain + "_" + tested + "_time_boxplots.png\'\n\n")
    """

    outfile.write("#Create the border around the screen\n")
    outfile.write("set border linewidth 1.5\n\n")
    
    outfile.write("#Generate the line and point styles for all four plots (2 scatter, 2 line)\n")
    outfile.write("#Color series 1 (for total time) will be a nice blue shown in the tutorial\n#  at www.gnuplotting.org/plotting-data/\n")
    outfile.write("#NOTE: Due to being a scatter plot, the line will have NO width\n")
    outfile.write("set style line 1 linecolor rgb \'#0060ad\' linetype 1 linewidth 0 pointtype 1 pointsize 2.5\n")
    outfile.write("#Color series 2 (for search time) will be a nice red shown in the same tutorial\n#NOTE: Due to being a scatter plot, the line will have NO width\n")
    outfile.write("set style line 2 linecolor rgb \'#dd181f\' linetype 1 linewidth 0 pointtype 2 pointsize 2.5\n")
    outfile.write("#Color series 3 the same as series 1 since it is the line plot of the average of total time\n")
    outfile.write("set style line 3 linecolor rgb \'#0060ad\' linetype 1 linewidth 3 pointtype 1 pointsize 0\n")
    outfile.write("#Color series 4 the same as series 2 since it is the line plot of the average of search time\n")
    outfile.write("set style line 4 linecolor rgb \'#dd181f\' linetype 1 linewidth 3 pointtype 2 pointsize 0\n")

    #Now we plot the axis information, which is assumed without a data file
    #  to provide the maximum value
    outfile.write("#Setup the axes\n")
    outfile.write("set xtics 2\n")
    outfile.write("set xrange [0:" + str((to_problem - from_problem) + 2) + "]\n")
    #maxy is 2 for a magic number-based default, but can be modified with a dataset
    maxy = 2
    if data_file:
        infile = open(data_file, 'r')
        #Store all the data, delimited by whitespace and ignoring the 2 header lines
        #NOTE: The end of each line has some newline and return characters to remove
        data_dump = [map(float, line[:-2].split()) for line in (infile.readlines())[2:]]
        #No longer need the input file
        infile.close()
        #This mess takes the greatest total time (column 1) and the greatest
        #  search time (column 2) and then compares those two values for the max y-value
        maxy = max(max([i[1] for i in data_dump]), max([i[2] for i in data_dump]))
    outfile.write("set yrange [0:" + str(maxy) + "]\n")
    #Make sure the ytics are small/big enough that there are exactly 10 of them along the axis
    outfile.write("set ytics " + str(maxy / 10.0) + "\n\n")
    
    #Include a key, axes labels, and title
    outfile.write("#setup the key\n")
    outfile.write("set key ins vert left top\n\n")
    
    outfile.write("set xlabel \"IPC Problem Index\"\n")
    outfile.write("set ylabel \"Runtime (seconds)\"\n")
    outfile.write("set title \"" + domain[0].upper() + domain[1:] + " (LPG " + tested[0].upper() + tested[1:] + ")\"\n\n")

    #The actual plotting command
    if data_file:
        outfile.write("plot \'" + data_file[:data_file.find("box")] + data_file[(data_file.find("box")+len("box")):] + "\' ") #data_file is box version, but don't plot scatter and line plots with it!
    else:
        outfile.write("plot \'lpg_" + domain + "_" + tested + "_times.dat\' ")
    #Once the filename is used, the line info is the same
    outfile.write("index 0 with linespoints linestyle 1 t \'Total Time\', ")
    outfile.write("\'\' index 1 with linespoints linestyle 2 t \'Search Time\', ")
    outfile.write("\'\' index 2 with linespoints linestyle 3 t \'Average Total Time\', ")
    outfile.write("\'\' index 3 with linespoints linestyle 4 t \'Average Search Time\'\n")
    
    #Done with the output file
    outfile.close()

def plotComparisonGNU(from_problem, to_problem, domain = default_domain, data_file = None, filepath = default_path, output_file = ".gnu", logscale = False):
    """Creates a .gnu file for generating a boxplot of the above data (repair 
       vs. replan runtimes).

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (string) domain = the domain (either "openstacks" or "rovers" or "satellite" for now)
    (string) data_file = the name of the file with the data; uses a default if None
             [DEFAULT value = None]
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .gnu file, prepended by tested
             [DEFAULT value = ".gnu"]
    (boolean) logscale = whether the y-axis should be rendered in log-scale
             [DEFAULT value = False]
    Returns:
    (void)
    """
    #Columns of data_file
    PROBLEM_INSTANCE_COL = 0
    TOTAL_REPAIR_TIME_COL = 1
    SEARCH_REPAIR_TIME_COL = 2
    TOTAL_REPLAN_TIME_COL = 3
    SEARCH_REPLAN_TIME_COL = 4
    TOTAL_COLS = 5

    #Threshold for the smallest value allowed in logscale (since log(0) is problematic)
    threshold_value = 0.01

    #First create the file to which we will write the data
    outfile = open("plotTimes_compare" + output_file, 'w')

    #Begin with the shebang header
    ###NOTE: There are updates to the shebang header format based on Robert's 
    ###      efforts to get his machine to render PDFs properly - these may not
    ###      appear in other GNUplot file generating functions above!
    ###NOTE: We remove the newline at the end of the stdout for the which command
    gnuplot_path = subprocess.check_output(["which", "gnuplot"])[:-1]
    outfile.write("#!" + gnuplot_path + " -c\n\nname = \'lpg_" + domain + "_compare_time_plots\'\n\ncall \"../../../output-prefix.gnu\" ARG1\n\n")

    #Next is the general header information such as documentation, clearing
    #  anything cached, setup parameters, etc.
    outfile.write("#Plotting times taken to run LPG's plan repair and replan\n\n")
    """
    ###NOTE: The reset and file naming below are removed in exchange for Robert's
    ###      changes above (the PDF printing does not need the PNG printing stuff)
    outfile.write("reset\n\n")
    outfile.write("#PDF file failed to show axes; so changed to PNG...\n")
    outfile.write("set term pngcairo size 700,400\n")
    outfile.write("set output \'lpg_" + domain + "_" + "compare" + "_time_boxplots.png\'\n\n")
    """
    outfile.write("#Create the border around the screen\n")
    outfile.write("set border linewidth 1.5\n\n")
    
    outfile.write("#Generate the line and point styles for all four plots (2 scatter, 2 line)\n")
    outfile.write("#Color series 1 (for total repair time) will be a nice blue shown in the tutorial\n#  at www.gnuplotting.org/plotting-data/\n")
    outfile.write("#NOTE: Due to being a scatter plot, the line will have NO width\n")
    outfile.write("set style line 1 linecolor rgb \'#0060ad\' linetype 1 linewidth 0 pointtype 1 pointsize 2.5\n")
    outfile.write("#Color series 2 (for total replan time) will be a nice red shown in the same tutorial\n#NOTE: Due to being a scatter plot, the line will have NO width\n")
    outfile.write("set style line 2 linecolor rgb \'#dd181f\' linetype 1 linewidth 0 pointtype 2 pointsize 2.5\n")
    outfile.write("#Color series 3 the same as series 1 since it is the line plot of the average of total repair time\n")
    outfile.write("set style line 3 linecolor rgb \'#0060ad\' linetype 1 linewidth 3 pointtype 1 pointsize 0\n")
    outfile.write("#Color series 4 the same as series 2 since it is the line plot of the average of total replan time\n")
    outfile.write("set style line 4 linecolor rgb \'#dd181f\' linetype 1 linewidth 3 pointtype 2 pointsize 0\n")

    #Now we plot the axis information, which is assumed without a data file
    #  to provide the maximum value
    outfile.write("#Setup the axes\n")
    outfile.write("set xtics 2\n")
    outfile.write("set xrange [0:" + str((to_problem - from_problem) + 2) + "]\n")
    #maxy is 2 and miny is 0.1 for a magic number-based default, but can be modified with a dataset
    maxy = 2
    miny = 0.1
    if data_file:
        infile = open(data_file, 'r')
        #Store all the data, delimited by whitespace and ignoring the 2 header lines
        #NOTE: The end of each line has some newline and return characters to remove
        data_dump = [map(float, line[:-2].split()) for line in (infile.readlines())[2:]]
        #No longer need the input file
        infile.close()
        #This mess takes the greatest/least total time for the max/min y-value
        maxy = max(max([i[TOTAL_REPAIR_TIME_COL] for i in data_dump]), max([i[TOTAL_REPLAN_TIME_COL] for i in data_dump]))
        miny = min(min([i[TOTAL_REPAIR_TIME_COL] for i in data_dump if i[TOTAL_REPAIR_TIME_COL] != 0.0]), min([i[TOTAL_REPLAN_TIME_COL] for i in data_dump if i[TOTAL_REPLAN_TIME_COL] != 0.0]))
    #The y-axis's range depends on logarithmic scale or not
    #if logscale:
        #Thanks to https://stackoverflow.com/questions/40296851/gnuplot-log-plot-y-axis
        #  for info on getting the plot to look correct for logscale
    #    outfile.write("set logscale y 10\n")
    #    outfile.write("set yrange [" + str(numpy.log(max(miny,threshold_value)) / numpy.log(10.0)) + ":" + str(maxy * 1.1) + "]\n")
    #else:
    outfile.write("set yrange [0:" + str(maxy) + "]\n")
    #Make sure the ytics are small/big enough that there are exactly 10 of them along the axis
    #if logscale:
    #    outfile.write("set ytics " + str(numpy.log(maxy) / numpy.log(10.0) / 10.0) + "\n\n")
    #else:
    outfile.write("set ytics " + str(maxy / 10.0) + "\n\n")
        
    #Include a key, axes labels, and title
    outfile.write("#setup the key\n")
    outfile.write("set key ins vert left top\n\n")
    outfile.write("set xlabel \"IPC Problem Index\"\n")
    outfile.write("set ylabel \"Runtime (seconds)\"\n")
    outfile.write("set title \"" + domain[0].upper() + domain[1:] + " (LPG " + "Plan Repair vs. Replan Runtime" + ")\"\n\n")

    #The actual plotting command - GNUplot uses 1 as the first index
    #NOTE: To threshold values that are 0 in logscale (they go to -infinity),
    #      we apply a thresholding function
    if data_file:
    #    if logscale:
    #        outfile.write("plot \'" + data_file + "\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):($" + str(TOTAL_REPAIR_TIME_COL + 1) + " > " + str(threshold_value) + " ? $" + str(TOTAL_REPAIR_TIME_COL + 1) + " : " + str(threshold_value) + "):(0.5):1 t \'Time for Plan Repair\', \'\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):($" + str(TOTAL_REPLAN_TIME_COL + 1) + " > " + str(threshold_value) + " ? $" + str(TOTAL_REPLAN_TIME_COL + 1) + " : " + str(threshold_value) + "):(0.5):1 t \'Time for Replanning\'\n")
        #else:
        outfile.write("plot \'" + data_file[:data_file.find("box")] + data_file[(data_file.find("box")+len("box")):] + "\' ") #data_file is box version, but don't plot scatter and line plots with it!
    else:
        outfile.write("plot \'lpg_" + domain + "_" + "all" + "_times.dat\' ")

    #Once the filename is used, the line info is the same
    outfile.write("index 0 with linespoints linestyle 1 t \'Time for Plan Repair\', ")
    outfile.write("\'\' index 1 with linespoints linestyle 2 t \'Time for Replanning\', ")
    outfile.write("\'\' index 2 with linespoints linestyle 3 t \'Average Time for Plan Repair\', ")
    outfile.write("\'\' index 3 with linespoints linestyle 4 t \'Average Time for Replanning\'\n")
    
    #Done with the output file
    outfile.close()

def plotBoxTimes(from_problem, to_problem, num_trials, tested = "repair", filepath = default_path, output_file = "timesbox.dat"):
    """Puts all the times and their average into a (GNUplot) plottable .dat file
       that will render a boxplot

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .dat file, prepended by tested
             [DEFAULT value = "timesbox.dat"]
    Returns:
    (void)
    """
    #First create the file to which we will write the data
    outfile = open(tested + "_" + output_file, 'w')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order (it will be modified for .dat files)
    data_to_print = numpy.zeros((to_problem - from_problem + 1, num_trials * 2))
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            input_file = filepath + "lpg_" + tested + "_output_p" + (("0" + str(problem)) if problem < 10 else str(problem)) + "_trial" + str(trial) + ".txt"
            infile = open(input_file, 'r')
            #Store all the data, delimited by whitespace
            data_dump = [line.split() for line in infile.readlines()]
            #No longer need the input file
            infile.close()

            #print data_dump
            #print problem, trial, '\n'
            
            #Find the total and search time entries to record in the array
            #NOTE: The file might be empty if it hit a segmentation fault!
            #NOTE2: If segmentation fault comes from memory exhaustion, then the
            #       output file WILL contain data, but no time information
            if len(data_dump) == 0 or len([i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"]) == 0:
                data_to_print[problem - from_problem][trial] = -1.0
                data_to_print[problem - from_problem][trial + num_trials] = -1.0
            else:
                #WARNING: This is a bit of a hack, **assuming** that the fields are
                #  printed left-most with exact strings and tabbing format
                #NOTE: Since some lines are empty, check the length first!
                data_to_print[problem - from_problem][trial] = [i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"][0][2]
                data_to_print[problem - from_problem][trial + num_trials] = [i for i in data_dump if len(i) >= 3 and i[0]=="Search" and i[1]=="time:"][0][2]

    #Write the header row for what each data column represents in the scatter plot
    outfile.write("#Boxplot\n# Problem Number (X) | Total Time (Y) | Search Time (Z)\n")
    #Print each point in the boxplot, with both time values on the same line
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for (totalTimeValue, searchTimeValue) in zip(problemValues[:num_trials], problemValues[num_trials:]):
            outfile.write(str(problemId) + ' ' + str(totalTimeValue) + ' ' + str(searchTimeValue) + '\n')

    #Done with the output file
    outfile.flush()
    outfile.close()

def plotBoxAllTimes(from_problem, to_problem, num_trials, filepath = default_path, output_file = "alltimesbox.dat"):
    """Puts all the times and their average into a (GNUplot) plottable .dat file
       that will render a boxplot

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .dat file, prepended by tested
             [DEFAULT value = "timesbox.dat"]
    Returns:
    (void)
    """
    #Columns of plan_times.txt
    REPAIR_TIME_COL = 0
    REPLAN_TIME_COL = 1

    #Lists the possible tests, which will all be compiled into one file now
    total_tests = ["repair", "replan"]
    
    #First create the file to which we will write the data
    outfile = open(output_file, 'w')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order (it will be modified for .dat files)
    data_to_print = numpy.zeros((to_problem - from_problem + 1, num_trials * 2, len(total_tests)))
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            for tested in range(len(total_tests)):
                input_file = filepath + "lpg_" + total_tests[tested] + "_output_p" + (("0" + str(problem)) if problem < 10 else str(problem)) + "_trial" + str(trial) + ".txt"
                infile = open(input_file, 'r')
                #Store all the data, delimited by whitespace
                data_dump = [line.split() for line in infile.readlines()]
                #No longer need the input file
                infile.close()

                #print data_dump
                #print problem, trial, '\n'
            
                #Find the total and search time entries to record in the array
                #NOTE: The file might be empty if it hit a segmentation fault!
                #NOTE2: If segmentation fault comes from memory exhaustion, then the
                #       output file WILL contain data, but no time information
                if len(data_dump) == 0 or len([i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"]) == 0:
                    data_to_print[problem - from_problem][trial][tested] = -1.0
                    data_to_print[problem - from_problem][trial + num_trials][tested] = -1.0
                else:
                    #WARNING: This is a bit of a hack, **assuming** that the fields are
                    #  printed left-most with exact strings and tabbing format
                    #NOTE: Since some lines are empty, check the length first!
                    data_to_print[problem - from_problem][trial][tested] = [i for i in data_dump if len(i) >= 3 and i[0]=="Total" and i[1]=="time:"][0][2]
                    data_to_print[problem - from_problem][trial + num_trials][tested] = [i for i in data_dump if len(i) >= 3 and i[0]=="Search" and i[1]=="time:"][0][2]

    #Write the header row for what each data column represents in the scatter plot
    outfile.write("#Boxplot\n# Problem Number (X) | Total Plan Repair Time (Y1) | Plan Repair Search Time (Y2) | Total Replan Time (Y3) | Replan Search Time (Y4)\n")
    #Print each point in the boxplot, with both time values on the same line
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for (totalTimeValue, searchTimeValue) in zip(problemValues[:num_trials], problemValues[num_trials:]):
            outfile.write(str(problemId) + ' ' + str(totalTimeValue[REPAIR_TIME_COL]) + ' ' + str(searchTimeValue[REPAIR_TIME_COL]) + ' ' + str(totalTimeValue[REPLAN_TIME_COL]) + ' ' + str(searchTimeValue[REPLAN_TIME_COL]) + '\n')

    #Done with the output file
    outfile.flush()
    outfile.close()

def plotBoxGNU(from_problem, to_problem, tested = "repair", domain = default_domain, data_file = None, filepath = default_path, output_file = ".gnu"):
    """Creates a .gnu file for generating a boxplot of the above data

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) domain = the domain (either "openstacks" or "rovers" or "satellite" for now)
    (string) data_file = the name of the file with the data; uses a default if None
             [DEFAULT value = None]
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .gnu file, prepended by tested
             [DEFAULT value = ".gnu"]
    Returns:
    (void)
    """
    #First create the file to which we will write the data
    outfile = open("plotTimesBox_" + tested + output_file, 'w')

    #Begin with the shebang header
    outfile.write("#!/usr/bin/gnuplot\n\n")

    #Next is the general header information such as documentation, clearing
    #  anything cached, setup parameters, etc.
    outfile.write("#Plotting times taken to run LPG's plan repair\n\n")
    outfile.write("reset\n\n")
    outfile.write("#PDF file failed to show axes; so changed to PNG...\n")
    outfile.write("set term pngcairo size 700,400\n")
    outfile.write("set output \'lpg_" + domain + "_" + tested + "_time_boxplots.png\'\n\n")
    outfile.write("#Create the border around the screen\n")
    outfile.write("set border linewidth 1.5\n\n")
    outfile.write("#Generates the boxplot style\n")
    outfile.write("set style data boxplot\n\n")

    #Now we plot the axis information, which is assumed without a data file
    #  to provide the maximum value
    outfile.write("#Setup the axes\n")
    outfile.write("set xtics (\" \" 1) #This hides the default tic marks\n")
    outfile.write("set xrange [0:" + str((to_problem - from_problem) + 2) + "]\n")
    #maxy is 2 for a magic number-based default, but can be modified with a dataset
    maxy = 2
    if data_file:
        infile = open(data_file, 'r')
        #Store all the data, delimited by whitespace and ignoring the 2 header lines
        #NOTE: The end of each line has some newline and return characters to remove
        data_dump = [map(float, line[:-2].split()) for line in (infile.readlines())[2:]]
        #No longer need the input file
        infile.close()
        #This mess takes the greatest total time (column 1) and the greatest
        #  search time (column 2) and then compares those two values for the max y-value
        maxy = max(max([i[1] for i in data_dump]), max([i[2] for i in data_dump]))
    outfile.write("set yrange [0:" + str(maxy) + "]\n")
    #Make sure the ytics are small/big enough that there are exactly 10 of them along the axis
    outfile.write("set ytics " + str(maxy / 10.0) + "\n\n")
    
    #Include a key, axes labels, and title
    outfile.write("#setup the key\n")
    outfile.write("set key ins vert left top\n\n")
    outfile.write("set xlabel \"IPC Problem Index\"\n")
    outfile.write("set ylabel \"Runtime (seconds)\"\n")
    outfile.write("set title \"" + domain[0].upper() + domain[1:] + " (LPG " + tested[0].upper() + tested[1:] + ")\"\n\n")

    #The actual plotting command
    if data_file:
        outfile.write("plot \'" + data_file + "\' using (1):2:(0.5):1 t \'Total Time\', \'\' using (1):3:(0.5):1 t \'Search Time\'")
    else:
        outfile.write("plot \'lpg_" + domain + "_" + tested + "_timesbox.dat\' using (1):2:(0.5):1 t \'Total Time\', \'\' using (1):3:(0.5):1 t \'Search Time\'\n")
    
    #Done with the output file
    outfile.close()

def plotComparisonBoxGNU(from_problem, to_problem, domain = default_domain, data_file = None, filepath = default_path, output_file = ".gnu", logscale = False):
    """Creates a .gnu file for generating a boxplot of the above data (repair 
       vs. replan runtimes).

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (string) domain = the domain (either "openstacks" or "rovers" or "satellite" for now)
    (string) data_file = the name of the file with the data; uses a default if None
             [DEFAULT value = None]
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .gnu file, prepended by tested
             [DEFAULT value = ".gnu"]
    (boolean) logscale = whether the y-axis should be rendered in log-scale
             [DEFAULT value = False]
    Returns:
    (void)
    """
    #Columns of data_file
    PROBLEM_INSTANCE_COL = 0
    TOTAL_REPAIR_TIME_COL = 1
    SEARCH_REPAIR_TIME_COL = 2
    TOTAL_REPLAN_TIME_COL = 3
    SEARCH_REPLAN_TIME_COL = 4
    TOTAL_COLS = 5

    #Threshold for the smallest value allowed in logscale (since log(0) is problematic)
    threshold_value = 0.01

    #First create the file to which we will write the data
    outfile = open("plotTimesBox_compare" + output_file, 'w')

    #Begin with the shebang header
    ###NOTE: There are updates to the shebang header format based on Robert's 
    ###      efforts to get his machine to render PDFs properly - these may not
    ###      appear in other GNUplot file generating functions above!
    ###NOTE: We remove the newline at the end of the stdout for the which command
    gnuplot_path = subprocess.check_output(["which", "gnuplot"])[:-1]
    outfile.write("#!" + gnuplot_path + " -c\n\nname = \'lpg_" + domain + "_compare_time_boxplots\'\n\ncall \"../../../output-prefix.gnu\" ARG1\n\n")

    #Next is the general header information such as documentation, clearing
    #  anything cached, setup parameters, etc.
    outfile.write("#Plotting times taken to run LPG's plan repair and replan\n\n")
    """
    ###NOTE: The reset and file naming below are removed in exchange for Robert's
    ###      changes above (the PDF printing does not need the PNG printing stuff)
    outfile.write("reset\n\n")
    outfile.write("#PDF file failed to show axes; so changed to PNG...\n")
    outfile.write("set term pngcairo size 700,400\n")
    outfile.write("set output \'lpg_" + domain + "_" + "compare" + "_time_boxplots.png\'\n\n")
    """
    outfile.write("#Create the border around the screen\n")
    outfile.write("set border linewidth 1.5\n\n")
    outfile.write("#Generates the boxplot style\n")
    outfile.write("set style data boxplot\n\n")

    #Now we plot the axis information, which is assumed without a data file
    #  to provide the maximum value
    outfile.write("#Setup the axes\n")
    outfile.write("set xtics (\" \" 1) #This hides the default tic marks\n")
    outfile.write("set xrange [0:" + str((to_problem - from_problem) + 2) + "]\n")
    #maxy is 2 and miny is 0.1 for a magic number-based default, but can be modified with a dataset
    maxy = 2
    miny = 0.1
    if data_file:
        infile = open(data_file, 'r')
        #Store all the data, delimited by whitespace and ignoring the 2 header lines
        #NOTE: The end of each line has some newline and return characters to remove
        data_dump = [map(float, line[:-2].split()) for line in (infile.readlines())[2:]]
        #No longer need the input file
        infile.close()
        #This mess takes the greatest/least total time for the max/min y-value
        maxy = max(max([i[TOTAL_REPAIR_TIME_COL] for i in data_dump]), max([i[TOTAL_REPLAN_TIME_COL] for i in data_dump]))
        miny = min(min([i[TOTAL_REPAIR_TIME_COL] for i in data_dump if i[TOTAL_REPAIR_TIME_COL] != 0.0]), min([i[TOTAL_REPLAN_TIME_COL] for i in data_dump if i[TOTAL_REPLAN_TIME_COL] != 0.0]))
    #The y-axis's range depends on logarithmic scale or not
    if logscale:
        #Thanks to https://stackoverflow.com/questions/40296851/gnuplot-log-plot-y-axis
        #  for info on getting the plot to look correct for logscale
        outfile.write("set logscale y 10\n")
        #outfile.write("set yrange [log(" + str(miny) + "):log(" + str(maxy) + ")]\n")
        outfile.write("set yrange [" + str(numpy.log(max(miny,threshold_value)) / numpy.log(10.0)) + ":" + str(maxy * 1.1) + "]\n")
    else:
        outfile.write("set yrange [0:" + str(maxy) + "]\n")
    #Make sure the ytics are small/big enough that there are exactly 10 of them along the axis
    if logscale:
        outfile.write("set ytics " + str(numpy.log(maxy) / numpy.log(10.0) / 10.0) + "\n\n")
    else:
        outfile.write("set ytics " + str(maxy / 10.0) + "\n\n")
        
    #Include a key, axes labels, and title
    outfile.write("#setup the key\n")
    outfile.write("set key ins vert left top\n\n")
    outfile.write("set xlabel \"IPC Problem Index\"\n")
    outfile.write("set ylabel \"Runtime (seconds)\"\n")
    outfile.write("set title \"" + domain[0].upper() + domain[1:] + " (LPG " + "Plan Repair vs. Replan Runtime" + ")\"\n\n")

    #The actual plotting command - GNUplot uses 1 as the first index
    #NOTE: To threshold values that are 0 in logscale (they go to -infinity),
    #      we apply a thresholding function
    if data_file:
        if logscale:
            outfile.write("plot \'" + data_file + "\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):($" + str(TOTAL_REPAIR_TIME_COL + 1) + " > " + str(threshold_value) + " ? $" + str(TOTAL_REPAIR_TIME_COL + 1) + " : " + str(threshold_value) + "):(0.5):1 t \'Time for Plan Repair\', \'\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):($" + str(TOTAL_REPLAN_TIME_COL + 1) + " > " + str(threshold_value) + " ? $" + str(TOTAL_REPLAN_TIME_COL + 1) + " : " + str(threshold_value) + "):(0.5):1 t \'Time for Replanning\'\n")
        else:
            outfile.write("plot \'" + data_file + "\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):" + str(TOTAL_REPAIR_TIME_COL + 1) + ":(0.5):1 t \'Time for Plan Repair\', \'\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):" + str(TOTAL_REPLAN_TIME_COL + 1) + ":(0.5):1 t \'Time for Replanning\'\n")
    else:
        outfile.write("plot \'lpg_" + domain + "_" + "all" + "_timesbox.dat\' using (1):2:(0.5):1 t \'Total Time\'\n")
    
    #Done with the output file
    outfile.close()

def main():
    #Setup and apply the command-line argument for the domain name (optional arg)
    #NOTE: This will be good in case the default at the top is accidentally changed
    #CITE: https://docs.python.org/3.3/library/argparse.html
    #UPDATE: When called via command-line, default_domain is not yet defined
    domainArgName = "domain"
    argstuff = argparse.ArgumentParser(description="Process LPG runtime information into GNUplot files")
    argstuff.add_argument("-" + domainArgName, default="satellite", type=str, help="The domain whose runtimes will be processed") #choices=["openstacks", "rovers", "satellite"])
    default_domain = vars(argstuff.parse_args())[domainArgName] #When empty, parses sys.argv by default

    #Variables that will serve as constants for the command calls below
    first_problem_file = 1
    #last_problem_file = 30 if (default_domain == "openstacks") else 20
    #applyLogScale = (default_domain == "openstacks") #Only use logscale in openstacks
    if default_domain=="openstacks":
        last_problem_file = 30
        applyLogScale = True
    else:
        last_problem_file = 20
        applyLogScale = False
    total_trials = 10
    test_approaches = ["repair", "replan"]

    #These are the commands in step 4 of the ReadME
    for test_approach in test_approaches:
        consolidateTimes(first_problem_file,last_problem_file,total_trials,test_approach)
        plotTimes(first_problem_file,last_problem_file,total_trials,test_approach)
        plotBoxTimes(first_problem_file,last_problem_file,total_trials,test_approach)

    plotAllTimes(first_problem_file,last_problem_file,total_trials)
    plotBoxAllTimes(first_problem_file,last_problem_file,total_trials)

    #These are the commands in step 5 of the ReadME
    #  They are normally run in the terminal, which subprocess can handle
    #  (Then step 6, using extractTimes.py again, can follow below)
    #NOTE: These mv commands set up files generated in step 4 with the correct
    #      names for use in step 6
    for test_approach in test_approaches:
        subprocess.check_output(["mv", test_approach + "_times.dat", "lpg_" + default_domain + "_" + test_approach + "_times.dat"])
        subprocess.check_output(["mv", test_approach + "_timesbox.dat", "lpg_" + default_domain + "_" + test_approach + "_timesbox.dat"])

    subprocess.check_output(["mv", "alltimes.dat", "lpg_" + default_domain + "_all_times.dat"])
    subprocess.check_output(["mv", "alltimesbox.dat", "lpg_" + default_domain + "_all_timesbox.dat"])

    #These are the commands in step 6 of the ReadME
    #NOTE: The box version is given to both .gnu generators for computing axes
    #      values, but non-box version will change the name in generated .gnu file
    for test_approach in test_approaches:
        plotGNU(first_problem_file,last_problem_file,test_approach,default_domain,data_file="lpg_" + default_domain + "_" + test_approach + "_timesbox.dat")
        plotBoxGNU(first_problem_file,last_problem_file,test_approach,default_domain,data_file="lpg_" + default_domain + "_" + test_approach + "_timesbox.dat")

    #NOTE: The box version is given to both .gnu generators for computing axes
    #      values, but non-box version will change the name in generated .gnu file
    plotComparisonGNU(first_problem_file,last_problem_file,default_domain,data_file="lpg_" + default_domain + "_all_timesbox.dat",logscale=applyLogScale)
    plotComparisonBoxGNU(first_problem_file,last_problem_file,default_domain,data_file="lpg_" + default_domain + "_all_timesbox.dat",logscale=applyLogScale)

    #Steps 7 and onwards all use the command line; so we are done with the Python stuff

#This allows the code to be called via command line
if __name__ == "__main__":
    main()
