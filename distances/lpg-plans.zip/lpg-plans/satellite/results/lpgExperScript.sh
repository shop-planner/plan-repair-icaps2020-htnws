#!/bin/sh

#This script will run the experiments for LPG planning on a specific domain
#Written by: Richard (Rick) G. Freedman
#In Collaboration with: Robert P. Goldman and Ugur Kuter
#Last Updated: 2019 March 18

#NOTE: This is the generic version, replace XXX with the correct domain name
domainName="satellite"
#The filename for the PDDL domain file might be different as well
domainFilename="adlSat.pddl"
domainPath="/Users/freedman/myFiles/sift/projects/laplata/trunk/code/shop2LPG/results/distanceComputations/lpg_plans/${domainName}/"
#NOTE: Also specify the path to LPG if it is different on your machine!
lpgPath="/Users/freedman/myFiles/sift/projects/laplata/LPG-CVS/"
#NOTE: The path applies to everything, including the input plan (which is
#      actually stored locally in this directory)
thisDirectory=`pwd`

#For the iterations themselves, store each change using diverged_plan as the
#  initial plan to repair
#NOTE: initNum is initial state iteration, goalNum is goal condition iteration, 
#      and trialNum is the trial ID number
for problemNum in 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20
do
    for trialNum in 0 1 2 3 4 5 6 7 8 9
    do
	echo "Running Problem ${problemNum}, trial ${trialNum}"

	#NOTE: Made input_plan's path relative and, other paths can be global...

	###The plan repair version
	${lpgPath}lpg -o ${domainPath}${domainFilename} -f ${domainPath}repair_p${problemNum}_trial${trialNum}.pddl -n 1 -out lpg_repair_p${problemNum}_trial${trialNum}.sol -input_plan ../diverged_plan${problemNum}_trial${trialNum}.sol -same_objects -adapt_all_diff -seed 11200411 > lpg_repair_output_p${problemNum}_trial${trialNum}.txt

	###The replan version
	${lpgPath}lpg -o ${domainPath}${domainFilename} -f ${domainPath}repair_p${problemNum}_trial${trialNum}.pddl -n 1 -out lpg_replan_p${problemNum}_trial${trialNum}.sol -same_objects -adapt_all_diff -seed 11200411 > lpg_replan_output_p${problemNum}_trial${trialNum}.txt
    done
done
