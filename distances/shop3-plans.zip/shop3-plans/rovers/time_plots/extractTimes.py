"""extractTimes.py

Started On: 05 November 2018
Last Updated: 27 September 2019

Extracts the time durations for plan repair studies and puts them into a .csv file
NOTE: This is the SHOP version, which is different from the LPG version
"""

#Used for arrays and some math functions
import numpy
#Used to get system paths
import subprocess
#Used if called via the command line (gets those arguments)
import argparse

#The default domain is used if one is not provided
#default_domain = "openstacks"
default_domain = "rovers"
#default_domain = "satellite"

#The default path is used if one is not provided (remove the newline at the end of the stdout call)
default_path = subprocess.check_output(["pwd"])[:-1] + "/"
#default_path = "/Users/freedman/myFiles/sift/projects/laplata/trunk/code/shop2LPG/results/distanceComputations/ec2_shop2plans/" + default_domain + "/time_plots/"
#default_path = "/Users/freedman/myFiles/sift/projects/laplata/trunk/code/shop2LPG/results/distanceComputations/ec2_shop2plans/rovers/time_plots/"
#default_path = "/Users/freedman/myFiles/sift/projects/laplata/trunk/code/shop2LPG/results/distanceComputations/ec2_shop2plans/satellite/time_plots/"

def consolidateTimes(from_problem, to_problem, num_trials, filepath = default_path, output_file = "times.csv"):
    """Put all the times into a well-organized spreadsheet in the .csv format

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .csv file, prepended by tested
             [DEFAULT value = "times.csv"]
    Returns:
    (void)
    """
    #First create the file to which we will write the data
    outfile = open(output_file, 'w')
    #Write the header row for what each data column represents
    outfile.write("Problem Number")
    for trial in range(num_trials): outfile.write(",Repair Time Trial" + str(trial))
    for trial in range(num_trials): outfile.write(",Replan Time Trial" + str(trial))
    outfile.write('\n')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order
    data_to_print = numpy.zeros(num_trials * 2)

    #Read in the file with all the SHOP2 plan repair & replanning times
    input_file = filepath + "plan_times.txt"
    infile = open(input_file, 'r')
    #Store all the data, delimited by whitespace
    all_data_dump = [line.split(',') for line in infile.readlines()]
    #No longer need the input file
    infile.close()
    #print all_data_dump
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            #Only need the current line for the current problem and trial
            data_dump = all_data_dump[(num_trials * (problem - from_problem)) + trial]
            if len(data_dump) != 4:
                data_to_print[trial] = -1.0
                data_to_print[trial + num_trials] = -1.0
            else:
                #WARNING: This is a bit of a hack, **assuming** that the fields are
                #  printed in order of repair time and then replan time
                data_to_print[trial] = data_dump[0]
                data_to_print[trial + num_trials] = data_dump[1]

        #Print the line over all the trials for the problem before moving onto the next one
        outfile.write(str(problem))
        for i in data_to_print: outfile.write("," + str(i))
        outfile.write('\n')

    #Done with the output file
    outfile.flush()
    outfile.close()

def plotTimes(from_problem, to_problem, num_trials, tested = "repair", filepath = default_path, output_file = "times.dat"):
    """Puts all the times and their average into a (GNUplot) plottable .dat file

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .dat file, prepended by tested
             [DEFAULT value = "times.dat"]
    Returns:
    (void)
    """
    #First create the file to which we will write the data
    outfile = open(tested + "_" + output_file, 'w')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order (it will be modified for .dat files)
    data_to_print = numpy.zeros((to_problem - from_problem + 1, num_trials))

    input_file = filepath + "plan_times.txt"
    infile = open(input_file, 'r')
    #Store all the data, delimited by whitespace
    all_data_dump = [line.split(',') for line in infile.readlines()]
    #No longer need the input file
    infile.close()
    #print data_dump
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            #Only need the current line for the current problem and trial
            data_dump = all_data_dump[(num_trials * (problem - from_problem)) + trial]
            if len(data_dump) != 4:
                data_to_print[problem - from_problem][trial] = -1.0
            else:
                #WARNING: This is a bit of a hack, **assuming** that the fields are
                #  printed in order of repair time and then replan time
                #NOTE: The last else case (for an invalid tested value) is intentionally out of bounds
                data_to_print[problem - from_problem][trial] = data_dump[0 if tested=="repair" else (1 if tested=="replan" else len(data_dump))]

    #Write the header row for what each data column represents in the scatter plot
    outfile.write("#Scatter Plot (index 0)\n# Problem Number (X) | Total Time (Y)\n")
    #Print each point in the scatter plot, a blank space in between will not draw the line
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for totalTimeValue in problemValues[:num_trials]:
            outfile.write(str(problemId) + ' ' + str(totalTimeValue) + '\n\n')

    #Need two extra line breaks for the new set of points to plot
    outfile.write("\n#Line Plot (index 1)\n# Problem Number (X) | Average Total Time (Y)\n")
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        outfile.write(str(problemId) + ' ' + str(numpy.average(numpy.array([i for i in problemValues[:num_trials] if i >= 0.0]))) + '\n')

    #Done with the output file
    outfile.flush()
    outfile.close()

def plotBoxTimes(from_problem, to_problem, num_trials, tested = "repair", filepath = default_path, output_file = "timesbox.dat"):
    """Puts all the times and their average into a (GNUplot) plottable .dat file
       that will render a boxplot

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .dat file, prepended by tested
             [DEFAULT value = "timesbox.dat"]
    Returns:
    (void)
    """
    #Columns of plan_times.txt
    REPAIR_TIME_COL = 0
    REPLAN_TIME_COL = 1
    ORIG_OVERHEAD_TIME_COL = 2
    ORIG_NO_OVERHEAD_TIME_COL = 3

    #First create the file to which we will write the data
    outfile = open(tested + "_" + output_file, 'w')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order (it will be modified for .dat files)
    data_to_print = numpy.zeros((to_problem - from_problem + 1, num_trials))
    
    input_file = filepath + "plan_times.txt"
    infile = open(input_file, 'r')
    #Store all the data, delimited by whitespace
    all_data_dump = [line.split(',') for line in infile.readlines()]
    #No longer need the input file
    infile.close()
    #print data_dump
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            #Only need the current line for the current problem and trial
            data_dump = all_data_dump[(num_trials * (problem - from_problem)) + trial]
            if len(data_dump) != 4:
                data_to_print[problem - from_problem][trial] = -1.0
            else:
                #WARNING: This is a bit of a hack, **assuming** that the fields are
                #  printed in order of repair time and then replan time
                #NOTE: The last else case (for an invalid tested value) is intentionally out of bounds
                data_to_print[problem - from_problem][trial] = data_dump[REPAIR_TIME_COL if tested=="repair" else (REPLAN_TIME_COL if tested=="replan" else len(data_dump))]

    #Write the header row for what each data column represents in the scatter plot
    outfile.write("#Boxplot\n# Problem Number (X) | Total Time (Y)\n")
    #Print each point in the boxplot, with both time values on the same line
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for totalTimeValue in problemValues[:num_trials]:
            outfile.write(str(problemId) + ' ' + str(totalTimeValue) + '\n')

    #Done with the output file
    outfile.flush()
    outfile.close()

def plotBoxAllTimes(from_problem, to_problem, num_trials, filepath = default_path, output_file = "alltimesbox.dat"):
    """Puts all the times and their average into a (GNUplot) plottable .dat file
       that will render a boxplot

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (int) num_trials = the number of trials run per problem file
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .dat file, prepended by tested
             [DEFAULT value = "overheadtimesbox.dat"]
    Returns:
    (void)
    """
    #Columns of plan_times.txt
    REPAIR_TIME_COL = 0
    REPLAN_TIME_COL = 1
    ORIG_OVERHEAD_TIME_COL = 2
    ORIG_NO_OVERHEAD_TIME_COL = 3
    TOTAL_COLS = 4

    #First create the file to which we will write the data
    outfile = open(output_file, 'w')

    #Also generate the CSV-based table because some values will be obtained out
    #  of printing order (it will be modified for .dat files)
    data_to_print = numpy.zeros((to_problem - from_problem + 1, num_trials, TOTAL_COLS))
    
    input_file = filepath + "plan_times.txt"
    infile = open(input_file, 'r')
    #Store all the data, delimited by whitespace
    all_data_dump = [line.split(',') for line in infile.readlines()]
    #No longer need the input file
    infile.close()
    #print data_dump
    
    #Now we begin to read the results file one-by-one
    for problem in range(from_problem, to_problem + 1):
        for trial in range(num_trials):
            #Only need the current line for the current problem and trial
            data_dump = all_data_dump[(num_trials * (problem - from_problem)) + trial]
            if len(data_dump) != 4:
                for col in range(TOTAL_COLS):
                    data_to_print[problem - from_problem][trial][col] = -1.0
            else:
                #WARNING: This is a bit of a hack, **assuming** that the fields are
                #  printed in order of specified by the column constants above
                for col in range(TOTAL_COLS):
                    data_to_print[problem - from_problem][trial][col] = data_dump[col]

    #Write the header row for what each data column represents in the scatter plot
    outfile.write("#Boxplot\n# Problem Number (X) | Total Plan Repair Time | Total Replan Time | Total Time with Overhead (Y2) | Total Time without Overhead (Y3)\n")
    #Print each point in the boxplot, with both time values on the same line
    for (problemId, problemValues) in zip(range(from_problem, to_problem + 1), data_to_print):
        for totalTimeValue in problemValues[:num_trials]:
            outfile.write(str(problemId) + ' ' + str(totalTimeValue[REPAIR_TIME_COL]) + ' ' + str(totalTimeValue[REPLAN_TIME_COL]) + ' ' + str(totalTimeValue[ORIG_OVERHEAD_TIME_COL]) + ' ' + str(totalTimeValue[ORIG_NO_OVERHEAD_TIME_COL]) + '\n')

    #Done with the output file
    outfile.flush()
    outfile.close()

def plotBoxGNU(from_problem, to_problem, tested = "repair", domain = default_domain, data_file = None, filepath = default_path, output_file = ".gnu"):
    """Creates a .gnu file for generating a boxplot of the above data

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (string) tested = the test performed (either "repair" or "replan" for now)
    (string) domain = the domain (either "openstacks" or "rovers" or "satellite" for now)
    (string) data_file = the name of the file with the data; uses a default if None
             [DEFAULT value = None]
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .gnu file, prepended by tested
             [DEFAULT value = ".gnu"]
    Returns:
    (void)
    """
    #First create the file to which we will write the data
    outfile = open("plotTimesBox_" + tested + output_file, 'w')

    #Begin with the shebang header
    ###NOTE: There are updates to the shebang header format based on Robert's 
    ###      efforts to get his machine to render PDFs properly - these may not
    ###      appear in other GNUplot file generating functions above!
    ###NOTE: We remove the newline at the end of the stdout for the which command
    gnuplot_path = subprocess.check_output(["which", "gnuplot"])[:-1]
    outfile.write("#!" + gnuplot_path + " -c\n\nname = \'shop2_" + domain + "_" + tested + "_time_boxplots\'\n\ncall \"../../../output-prefix.gnu\" ARG1\n\n")

    #Next is the general header information such as documentation, clearing
    #  anything cached, setup parameters, etc.
    outfile.write("#Plotting times taken to run SHOP2's plan repair\n\n")
    """
    ###NOTE: The reset and file naming below are removed in exchange for Robert's
    ###      changes above (the PDF printing does not need the PNG printing stuff)
    outfile.write("reset\n\n")
    outfile.write("#PDF file failed to show axes; so changed to PNG...\n")
    outfile.write("set term pngcairo size 700,400\n")
    outfile.write("set output \'shop2_" + domain + "_" + tested + "_time_boxplots.png\'\n\n")
    """
    outfile.write("#Create the border around the screen\n")
    outfile.write("set border linewidth 1.5\n\n")
    outfile.write("#Generates the boxplot style\n")
    outfile.write("set style data boxplot\n\n")

    #Now we plot the axis information, which is assumed without a data file
    #  to provide the maximum value
    outfile.write("#Setup the axes\n")
    outfile.write("set xtics (\" \" 1) #This hides the default tic marks\n")
    outfile.write("set xrange [0:" + str((to_problem - from_problem) + 2) + "]\n")
    #maxy is 2 for a magic number-based default, but can be modified with a dataset
    maxy = 2
    if data_file:
        infile = open(data_file, 'r')
        #Store all the data, delimited by whitespace and ignoring the 2 header lines
        #NOTE: The end of each line has some newline and return characters to remove
        data_dump = [map(float, line[:-2].split()) for line in (infile.readlines())[2:]]
        #No longer need the input file
        infile.close()
        #This mess takes the greatest total time (column 1) for the max y-value
        maxy = max([i[1] for i in data_dump])
    outfile.write("set yrange [0:" + str(maxy) + "]\n")
    #Make sure the ytics are small/big enough that there are exactly 10 of them along the axis
    outfile.write("set ytics " + str(maxy / 10.0) + "\n\n")
    
    #Include a key, axes labels, and title
    outfile.write("#setup the key\n")
    outfile.write("set key ins vert left top\n\n")
    outfile.write("set xlabel \"IPC Problem Index\"\n")
    outfile.write("set ylabel \"Runtime (seconds)\"\n")
    outfile.write("set title \"" + domain[0].upper() + domain[1:] + " (SHOPFixer " + tested[0].upper() + tested[1:] + ")\"\n\n")

    #The actual plotting command
    if data_file:
        outfile.write("plot \'" + data_file + "\' using (1):2:(0.5):1 t \'Total Time\'\n")
    else:
        outfile.write("plot \'shop2_" + domain + "_" + tested + "_timesbox.dat\' using (1):2:(0.5):1 t \'Total Time\'\n")
    
    #Done with the output file
    outfile.close()

def plotComparisonBoxGNU(from_problem, to_problem, domain = default_domain, data_file = None, filepath = default_path, output_file = ".gnu", logscale = False):
    """Creates a .gnu file for generating a boxplot of the above data (repair 
       vs. replan runtimes).

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (string) domain = the domain (either "openstacks" or "rovers" or "satellite" for now)
    (string) data_file = the name of the file with the data; uses a default if None
             [DEFAULT value = None]
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .gnu file, prepended by tested
             [DEFAULT value = ".gnu"]
    (boolean) logscale = whether the y-axis should be rendered in log-scale
             [DEFAULT value = False]
    Returns:
    (void)
    """
    #Columns of data_file
    PROBLEM_INSTANCE_COL = 0
    REPAIR_TIME_COL = 1
    REPLAN_TIME_COL = 2
    ORIG_OVERHEAD_TIME_COL = 3
    ORIG_NO_OVERHEAD_TIME_COL = 4
    TOTAL_COLS = 5

    #Threshold for the smallest value allowed in logscale (since log(0) is problematic)
    threshold_value = 0.01

    #First create the file to which we will write the data
    outfile = open("plotTimesBox_compare" + output_file, 'w')

    #Begin with the shebang header
    ###NOTE: There are updates to the shebang header format based on Robert's 
    ###      efforts to get his machine to render PDFs properly - these may not
    ###      appear in other GNUplot file generating functions above!
    ###NOTE: We remove the newline at the end of the stdout for the which command
    gnuplot_path = subprocess.check_output(["which", "gnuplot"])[:-1]
    outfile.write("#!" + gnuplot_path + " -c\n\nname = \'shop2_" + domain + "_compare_time_boxplots\'\n\ncall \"../../../output-prefix.gnu\" ARG1\n\n")

    #Next is the general header information such as documentation, clearing
    #  anything cached, setup parameters, etc.
    outfile.write("#Plotting times taken to run SHOP2's plan repair and replan\n\n")
    """
    ###NOTE: The reset and file naming below are removed in exchange for Robert's
    ###      changes above (the PDF printing does not need the PNG printing stuff)
    outfile.write("reset\n\n")
    outfile.write("#PDF file failed to show axes; so changed to PNG...\n")
    outfile.write("set term pngcairo size 700,400\n")
    outfile.write("set output \'shop2_" + domain + "_" + "compare" + "_time_boxplots.png\'\n\n")
    """
    outfile.write("#Create the border around the screen\n")
    outfile.write("set border linewidth 1.5\n\n")
    outfile.write("#Generates the boxplot style\n")
    outfile.write("set style data boxplot\n\n")

    #Now we plot the axis information, which is assumed without a data file
    #  to provide the maximum value
    outfile.write("#Setup the axes\n")
    outfile.write("set xtics (\" \" 1) #This hides the default tic marks\n")
    outfile.write("set xrange [0:" + str((to_problem - from_problem) + 2) + "]\n")
    #maxy is 2 and miny is 0.1 for a magic number-based default, but can be modified with a dataset
    maxy = 2
    miny = 0.1
    if data_file:
        infile = open(data_file, 'r')
        #Store all the data, delimited by whitespace and ignoring the 2 header lines
        #NOTE: The end of each line has some newline and return characters to remove
        data_dump = [map(float, line[:-2].split()) for line in (infile.readlines())[2:]]
        #No longer need the input file
        infile.close()
        #This mess takes the greatest/least total time for the max/min y-value
        maxy = max(max([i[REPAIR_TIME_COL] for i in data_dump]), max(i[REPLAN_TIME_COL] for i in data_dump))
        miny = min(min([i[REPAIR_TIME_COL] for i in data_dump]), min(i[REPLAN_TIME_COL] for i in data_dump))
    #The y-axis's range depends on logarithmic scale or not
    if logscale:
        #Thanks to https://stackoverflow.com/questions/40296851/gnuplot-log-plot-y-axis
        #  for info on getting the plot to look correct for logscale
        outfile.write("set logscale y 10\n")
        #outfile.write("set yrange [log(" + str(miny) + "):log(" + str(maxy) + ")]\n")
        outfile.write("set yrange [" + str(numpy.log(max(miny,threshold_value)) / numpy.log(10.0)) + ":" + str(maxy * 1.1) + "]\n")
    else:
        outfile.write("set yrange [0:" + str(maxy) + "]\n")
    #Make sure the ytics are small/big enough that there are exactly 10 of them along the axis
    if logscale:
        outfile.write("set ytics " + str(numpy.log(maxy) / numpy.log(10.0) / 10.0) + "\n\n")
    else:
        outfile.write("set ytics " + str(maxy / 10.0) + "\n\n")
        
    #Include a key, axes labels, and title
    outfile.write("#setup the key\n")
    outfile.write("set key ins vert left top\n\n")
    outfile.write("set xlabel \"IPC Problem Index\"\n")
    outfile.write("set ylabel \"Runtime (seconds)\"\n")
    outfile.write("set title \"" + domain[0].upper() + domain[1:] + " (SHOPFixer " + "Plan Repair vs. Replan Runtime" + ")\"\n\n")

    #The actual plotting command - GNUplot uses 1 as the first index
    #NOTE: To threshold values that are 0 in logscale (they go to -infinity),
    #      we apply a thresholding function
    if data_file:
        if logscale:
            outfile.write("plot \'" + data_file + "\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):($" + str(REPAIR_TIME_COL + 1) + " > " + str(threshold_value) + " ? $" + str(REPAIR_TIME_COL + 1) + " : " + str(threshold_value) + "):(0.5):1 t \'Time for Plan Repair\', \'\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):($" + str(REPLAN_TIME_COL + 1) + " > " + str(threshold_value) + " ? $" + str(REPLAN_TIME_COL + 1) + " : " + str(threshold_value) + "):(0.5):1 t \'Time for Replanning\'\n")
        else:
            outfile.write("plot \'" + data_file + "\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):" + str(REPAIR_TIME_COL + 1) + ":(0.5):1 t \'Time for Plan Repair\', \'\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):" + str(REPLAN_TIME_COL + 1) + ":(0.5):1 t \'Time for Replanning\'\n")
    else:
        outfile.write("plot \'shop2_" + domain + "_" + "all" + "_timesbox.dat\' using (1):2:(0.5):1 t \'Total Time\'\n")
    
    #Done with the output file
    outfile.close()

def plotOverheadBoxGNU(from_problem, to_problem, domain = default_domain, data_file = None, filepath = default_path, output_file = ".gnu", logscale = False):
    """Creates a .gnu file for generating a boxplot of the above data (original
       plan only: with vs. without overhead).

    Parameters:
    (int) from_problem = the lower bound (inclusive) index of problem files
    (int) to_problem = the upper bound (inclusive) index of problem files
    (string) domain = the domain (either "openstacks" or "rovers" or "satellite" for now)
    (string) data_file = the name of the file with the data; uses a default if None
             [DEFAULT value = None]
    (string) filepath = the path to which the files with the results are locate
             [DEFAULT value = default_path]
    (string) output_file = the name of the generated .gnu file, prepended by tested
             [DEFAULT value = ".gnu"]
    (boolean) logscale = whether the y-axis should be rendered in log-scale
             [DEFAULT value = False]
    Returns:
    (void)
    """
    #Columns of data_file
    PROBLEM_INSTANCE_COL = 0
    REPAIR_TIME_COL = 1
    REPLAN_TIME_COL = 2
    ORIG_OVERHEAD_TIME_COL = 3
    ORIG_NO_OVERHEAD_TIME_COL = 4
    TOTAL_COLS = 5

    #Threshold for the smallest value allowed in logscale (since log(0) is problematic)
    threshold_value = 0.01

    #First create the file to which we will write the data
    outfile = open("plotTimesBox_overhead" + output_file, 'w')

    #Begin with the shebang header
    ###NOTE: There are updates to the shebang header format based on Robert's 
    ###      efforts to get his machine to render PDFs properly - these may not
    ###      appear in other GNUplot file generating functions above!
    ###NOTE: We remove the newline at the end of the stdout for the which command
    gnuplot_path = subprocess.check_output(["which", "gnuplot"])[:-1]
    outfile.write("#!" + gnuplot_path + " -c\n\nname = \'shop2_" + domain + "_overhead_time_boxplots\'\n\ncall \"../../../output-prefix.gnu\" ARG1\n\n")

    #Next is the general header information such as documentation, clearing
    #  anything cached, setup parameters, etc.
    outfile.write("#Plotting times taken to run SHOP2's planner with and without overhead for repair\n\n")
    """
    ###NOTE: The reset and file naming below are removed in exchange for Robert's
    ###      changes above (the PDF printing does not need the PNG printing stuff)
    outfile.write("reset\n\n")
    outfile.write("#PDF file failed to show axes; so changed to PNG...\n")
    outfile.write("set term pngcairo size 700,400\n")
    outfile.write("set output \'shop2_" + domain + "_" + "overhead" + "_time_boxplots.png\'\n\n")
    """
    outfile.write("#Create the border around the screen\n")
    outfile.write("set border linewidth 1.5\n\n")
    outfile.write("#Generates the boxplot style\n")
    outfile.write("set style data boxplot\n\n")

    #Now we plot the axis information, which is assumed without a data file
    #  to provide the maximum value
    outfile.write("#Setup the axes\n")
    outfile.write("set xtics (\" \" 1) #This hides the default tic marks\n")
    outfile.write("set xrange [0:" + str((to_problem - from_problem) + 2) + "]\n")
    #maxy is 2 and miny is 0.1 for a magic number-based default, but can be modified with a dataset
    maxy = 2
    miny = 0.1
    if data_file:
        infile = open(data_file, 'r')
        #Store all the data, delimited by whitespace and ignoring the 2 header lines
        #NOTE: The end of each line has some newline and return characters to remove
        data_dump = [map(float, line[:-2].split()) for line in (infile.readlines())[2:]]
        #No longer need the input file
        infile.close()
        #This mess takes the greatest/least total time for the max/min y-value
        maxy = max(max([i[ORIG_OVERHEAD_TIME_COL] for i in data_dump]), max([i[ORIG_NO_OVERHEAD_TIME_COL] for i in data_dump]))
        miny = min(min([i[ORIG_OVERHEAD_TIME_COL] for i in data_dump]), min([i[ORIG_NO_OVERHEAD_TIME_COL] for i in data_dump]))
    #The y-axis's range depends on logarithmic scale or not
    if logscale:
        #Thanks to https://stackoverflow.com/questions/40296851/gnuplot-log-plot-y-axis
        #  for info on getting the plot to look correct for logscale
        outfile.write("set logscale y 10\n")
        #outfile.write("set yrange [log(" + str(miny) + "):log(" + str(maxy) +")]\n")
        outfile.write("set yrange [" + str(numpy.log(max(miny,threshold_value)) / numpy.log(10.0)) + ":" + str(maxy * 1.1) + "]\n")
    else:
        outfile.write("set yrange [0:" + str(maxy) + "]\n")
    #Make sure the ytics are small/big enough that there are exactly 10 of them along the axis
    if logscale:
        outfile.write("set ytics " + str(numpy.log(maxy) / numpy.log(10.0) / 10.0) + "\n\n")
    else:
        outfile.write("set ytics " + str(maxy / 10.0) + "\n\n")
    
    #Include a key, axes labels, and title
    outfile.write("#setup the key\n")
    outfile.write("set key ins vert left top\n\n")
    outfile.write("set xlabel \"IPC Problem Index\"\n")
    outfile.write("set ylabel \"Runtime (seconds)\"\n")
    outfile.write("set title \"" + domain[0].upper() + domain[1:] + " (SHOPFixer " + "overhead"[0].upper() + "overhead"[1:] + ")\"\n\n")

    #The actual plotting command - GNUplot uses 1 as the first index
    #NOTE: To threshold values that are 0 in logscale (they go to -infinity),
    #      we apply a thresholding function
    if data_file:
        if logscale:
            outfile.write("plot \'" + data_file + "\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):($" + str(ORIG_OVERHEAD_TIME_COL + 1) + " > " + str(threshold_value) + " ? $" + str(ORIG_OVERHEAD_TIME_COL + 1) + " : " + str(threshold_value) + "):(0.5):1 t \'Time with Overhead\', \'\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):($" + str(ORIG_NO_OVERHEAD_TIME_COL + 1) + " > " + str(threshold_value) + " ? $" + str(ORIG_NO_OVERHEAD_TIME_COL + 1) + " : " + str(threshold_value) + "):(0.5):1 t \'Time without Overhead\'\n")
        else:
            outfile.write("plot \'" + data_file + "\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):" + str(ORIG_OVERHEAD_TIME_COL + 1) + ":(0.5):1 t \'Time with Overhead\', \'\' using (" + str(PROBLEM_INSTANCE_COL + 1) + "):" + str(ORIG_NO_OVERHEAD_TIME_COL + 1) + ":(0.5):1 t \'Time without Overhead\'\n")
    else:
        outfile.write("plot \'shop2_" + domain + "_" + "all" + "_timesbox.dat\' using (1):2:(0.5):1 t \'Total Time\'\n")
    
    #Done with the output file
    outfile.close()

def main():
    #Setup and apply the command-line argument for the domain name (optional arg)
    #NOTE: This will be good in case the default at the top is accidentally changed
    #CITE: https://docs.python.org/3.3/library/argparse.html
    #UPDATE: When called via command-line, default_domain is not yet defined
    domainArgName = "domain"
    argstuff = argparse.ArgumentParser(description="Process LPG runtime information into GNUplot files")
    argstuff.add_argument("-" + domainArgName, default="openstacks", type=str, help="The domain whose runtimes will be processed") #choices=["openstacks", "rovers", "satellite"])
    default_domain = vars(argstuff.parse_args())[domainArgName] #When empty, parses sys.argv by default

    #Variables that will serve as constants for the command calls below
    first_problem_file = 1
    #last_problem_file = 30 if (default_domain == "openstacks") else 20
    #applyLogScale = (default_domain == "openstacks") #Only use logscale in openstacks
    if default_domain=="openstacks":
        last_problem_file = 30
        applyLogScale = True
    else:
        last_problem_file = 20
        applyLogScale = False
    total_trials = 10
    test_approaches = ["repair", "replan"]

    #These are the commands in step 3 of the ReadME
    #NOTE: Unlike the LPG version, consolidateTimes for SHOP version does not
    #      need test_approach
    consolidateTimes(first_problem_file,last_problem_file,total_trials)
    for test_approach in test_approaches:
        plotTimes(first_problem_file,last_problem_file,total_trials,test_approach)
        plotBoxTimes(first_problem_file,last_problem_file,total_trials,test_approach)

    plotBoxAllTimes(first_problem_file,last_problem_file,total_trials)

    #These are the commands in step 4 of the ReadME
    #  They are normally run in the terminal, which subprocess can handle
    #  (Then step 6, using extractTimes.py again, can follow below)
    #NOTE: These mv commands set up files generated in step 3 with the correct
    #      names for use in step 5
    for test_approach in test_approaches:
        subprocess.check_output(["mv", test_approach + "_times.dat", "shop2_" + default_domain + "_" + test_approach + "_times.dat"])
        subprocess.check_output(["mv", test_approach + "_timesbox.dat", "shop2_" + default_domain + "_" + test_approach + "_timesbox.dat"])

    subprocess.check_output(["mv", "alltimesbox.dat", "shop2_" + default_domain + "_all_timesbox.dat"])

    #These are the commands in step 5 of the ReadME
    for test_approach in test_approaches:
        plotBoxGNU(first_problem_file,last_problem_file,test_approach,default_domain,data_file="shop2_" + default_domain + "_" + test_approach + "_timesbox.dat")

    plotComparisonBoxGNU(first_problem_file,last_problem_file,default_domain,data_file="shop2_" + default_domain + "_all_timesbox.dat",logscale=applyLogScale)
    plotOverheadBoxGNU(first_problem_file,last_problem_file,default_domain,data_file="shop2_" + default_domain + "_all_timesbox.dat",logscale=applyLogScale)

    #Steps 6 and onwards all use the command line; so we are done with the Python stuff

#This allows the code to be called via command line
if __name__ == "__main__":
    main()
